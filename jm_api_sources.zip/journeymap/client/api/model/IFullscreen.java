package journeymap.client.api.model;

import journeymap.client.api.display.Context;
import journeymap.client.api.util.UIState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.registry.RegistryKey;
import net.minecraft.world.World;

public interface IFullscreen
{
    /**
     * Updates to a maptype.
     *
     * @param mapType   - The maptype.
     * @param vSlice    - The slice.
     * @param dimension - The dimension
     */
    void updateMapType(Context.MapType mapType, Integer vSlice, RegistryKey<World> dimension);

    /**
     * Moves to the next maptype
     */
    void toggleMapType();

    /**
     * Zooms in
     */
    void zoomIn();

    /**
     * Zoomes out.
     */
    void zoomOut();

    /**
     * Centers the map on x, z coord
     *
     * @param x - The X coord.
     * @param z - The Z coord.
     */
    void centerOn(double x, double z);

    /**
     * Closes the map.
     */
    void close();

    /**
     * Gets the current UIState
     *
     * @return - The uiState.
     */
    UIState getUiState();

    /**
     * Gets minecraft
     *
     * @return Minecraft
     */
    MinecraftClient getMinecraft();

    /**
     * Gets the screen.
     *
     * @return the Screen.
     */
    Screen getScreen();
}
